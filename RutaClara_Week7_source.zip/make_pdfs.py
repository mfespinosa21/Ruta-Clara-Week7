from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Preformatted, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.utils import ImageReader
from pathlib import Path
from xml.sax.saxutils import escape
import re

ROOT=Path(__file__).parent
OUT=ROOT/'deliverables'
OUT.mkdir(exist_ok=True)
styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name='TitleCustom',parent=styles['Title'],fontName='Helvetica-Bold',fontSize=21,leading=25,textColor=colors.HexColor('#0a3650'),spaceAfter=16))
styles.add(ParagraphStyle(name='SectionCustom',parent=styles['Heading2'],fontSize=13,leading=16,textColor=colors.HexColor('#087fa8'),spaceBefore=15,spaceAfter=7))
styles.add(ParagraphStyle(name='BodyCustom',parent=styles['BodyText'],fontSize=9.5,leading=14,spaceAfter=7))
styles.add(ParagraphStyle(name='CodeCustom',fontName='Courier',fontSize=6.6,leading=9,textColor=colors.HexColor('#213e50')))

def footer(c,doc):
 c.saveState();c.setStrokeColor(colors.HexColor('#c4dce4'));c.line(45,43,550,43)
 c.setFont('Helvetica',8);c.setFillColor(colors.HexColor('#54717e'))
 c.drawString(45,30,'Fernanda Espinosa · Week 7 · Datos simulados')
 c.drawRightString(550,30,str(doc.page));c.restoreState()

def create(name, title, source, packet=False):
 story=[Paragraph(title,styles['TitleCustom'])]
 if packet:
  img=Image(str(ROOT/'assets/mockup.png'))
  img.drawWidth=190;img.drawHeight=338
  story += [Paragraph('Mockup generado con IA · concepto, no captura del producto',styles['BodyCustom']),img,PageBreak()]
 lines=(ROOT/source).read_text().splitlines()
 in_code=False;code=[]
 for line in lines:
  if line.startswith('# '):continue
  if line.startswith('!['):continue
  if line.startswith('```'):
   if in_code:
    story.append(Preformatted('\n'.join(code),styles['CodeCustom']));code=[]
   in_code=not in_code;continue
  if in_code:
   code.append(line);continue
  if not line.strip():
   story.append(Spacer(1,5));continue
  if line.startswith('## '):
   story.append(Paragraph(escape(line[3:]),styles['SectionCustom']));continue
  if line.startswith('|'):
   story.append(Paragraph(escape(line),styles['CodeCustom']));continue
  line=re.sub(r'\*\*(.*?)\*\*',r'<b>\1</b>',escape(line))
  story.append(Paragraph(line,styles['BodyCustom']))
 doc=SimpleDocTemplate(str(OUT/name),pagesize=(595,842),leftMargin=45,rightMargin=45,topMargin=45,bottomMargin=57)
 doc.build(story,onFirstPage=footer,onLaterPages=footer)

create('PACKET_FernandaEspinosa.pdf','Ruta Clara · Packet','docs/PACKET.md',True)
create('PERSONA_FernandaEspinosa.pdf','Persona test · preliminary','docs/PERSONA.md')
create('BUILDCHAT_FernandaEspinosa.pdf','Build transcript · documented decisions','docs/BUILDCHAT.md')
