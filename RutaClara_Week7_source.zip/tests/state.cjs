const fs=require('fs'),vm=require('vm'),assert=require('assert');
class Fake {
 constructor(id=''){this.id=id;this.value='';this.textContent='';this.children=[];this.style={};this.dataset={};this.classList={toggle(){}};this.handlers={};this.disabled=false}
 addEventListener(name,fn){this.handlers[name]=fn}
 dispatchEvent(e){this.handlers[e.type]?.(e)}
 append(...items){this.children.push(...items)}
 replaceChildren(...items){this.children=[...items]}
 setAttribute(){}
 focus(){}
 reset(){}
 get innerText(){return this.textContent}
}
const ids=['event-dot','public-alerts','decision-result','my-report','queue','description','suggestion','category','report-form','segment','alternative','expiry','form-error','voice','voice-status','alternate','original','refresh'];
const nodes=Object.fromEntries(ids.map(id=>[id,new Fake(id)]));
const tabs=['passenger','driver','operator'].map(name=>{const x=new Fake();x.dataset.tab=name;return x});
for(const t of tabs)nodes[t.dataset.tab]=new Fake(t.dataset.tab);
nodes.expiry.value='30';
const document={getElementById:id=>nodes[id],querySelectorAll:()=>tabs,createElement:tag=>new Fake(tag)};
const timers=[];
const context={document,window:{},Date,Math,Set,Map,Event:class{constructor(type){this.type=type}},setInterval:fn=>timers.push(fn)};
vm.createContext(context);
vm.runInContext(fs.readFileSync('dist/app.js','utf8'),context);
const app=context.window.RutaClaraTest;
assert(app,'test hook exists');
for(let i=0;i<3;i++){
 let hits=0,abstain=0;
 for(const phrase of [
  ['la parada se movió frente al mercado','nuevo punto para subir','ya no suben en esta esquina','esperar frente al hospital','cambio de punto de ascenso','parada ahora enfrente del mercado','temporalmente abordamos una cuadra adelante','la parada se cambió de lugar','no hay ascenso en la parada habitual','recoger pasajeros en la otra acera'],
  ['calle cerrada por obra','el camino está bloqueado','no se puede pasar por avenida','hay cierre de calle','obras impiden el paso','bloquearon el tramo','valla en la avenida','desvío por calle cerrada','el puente está bloqueado','no circula por el segmento cerrado'],
  ['servicio suspendido por ahora','no salen unidades','interrupción del servicio','colectivos dejaron de circular','pausa temporal de operaciones','sin servicio en la ruta','viajes detenidos','se suspendieron salidas','operación interrumpida','no hay unidades disponibles']
 ][i]){
   const got=app.classify(phrase);if(got===['Parada temporal','Camino bloqueado','Servicio interrumpido'][i])hits++;else if(!got)abstain++;
 }
 console.log('Class',i+1,'correct',hits,'abstain',abstain,'of 10');
}
assert.strictEqual(app.classify('ruido ajeno sin detalles'),null,'unclear phrase abstains');
function textTree(node){return [node.textContent,...node.children.map(textTree)].join(' ')}
assert(textTree(nodes['public-alerts']).includes('Farmacia Ejemplo'),'initial sample shown');
nodes.segment.value='Mercado – Hospital';nodes.category.value='Parada temporal';nodes.description.value='Corto';nodes.alternative.value='Entrada norte del hospital';
nodes['report-form'].handlers.submit({preventDefault(){}});
assert(nodes['form-error'].textContent.includes('8 y 180'),'short description rejected');
assert(textTree(nodes['public-alerts']).includes('Farmacia Ejemplo'),'invalid report does not replace visible notice');
nodes.segment.value='Mercado – Hospital';nodes.category.value='Parada temporal';nodes.description.value='La parada se movió frente al hospital';nodes.alternative.value='Entrada norte del hospital';
nodes['report-form'].handlers.submit({preventDefault(){}});
assert.strictEqual(app.getState().report.status,'pending');
assert(!textTree(nodes['public-alerts']).includes('Entrada norte'),'pending hidden');
assert(nodes.alternate.disabled,'decision blocked without notice');
const verify=nodes.queue.children[0].children.find(x=>x.children?.some(y=>y.textContent==='Verificar (simulado)')).children.find(x=>x.textContent==='Verificar (simulado)');
verify.onclick();
assert(textTree(nodes['public-alerts']).includes('Entrada norte'),'verified visible');
app.getState().report.expires=Date.now()-1;
nodes.refresh.onclick();
assert(nodes.alternate.disabled,'expired notice blocks decision');
app.getState().report.expires=Date.now()+60*60000;
nodes.refresh.onclick();
nodes.alternate.onclick();
assert(app.getState().decision,'decision recorded');
const withdraw=nodes['my-report'].children[0].children.find(x=>x.textContent==='Retirar reporte');withdraw.onclick();
assert(nodes.alternate.disabled,'decision blocked on withdrawal');
assert.strictEqual(app.getState().decision,null,'stale decision cleared');
console.log('PASS state transitions, withdrawal, no-notice controls');
